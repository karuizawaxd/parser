import pandas as pd
import csv
from datetime import datetime

def read_domains_from_csv(filename):
    try:
        data = pd.read_csv(filename)
        print(f"Файл '{filename}' успешно загружен.")
        return data
    except Exception as e:
        print(f"Ошибка при чтении файла: {e}")
        return None

def save_to_csv(data, filename):
    try:
        data.to_csv(filename, index=False, encoding="utf-8")
        print(f"Данные сохранены в файл: {filename}")
    except Exception as e:
        print(f"Ошибка при сохранении файла: {e}")

def save_to_excel(data, filename):
    try:
        data.to_excel(filename, index=False)
        print(f"Данные сохранены в Excel файл: {filename}")
    except Exception as e:
        print(f"Ошибка при сохранении в Excel: {e}")

if __name__ == "__main__":
    print("Читаем данные из локальной базы...")

    input_filename = "domains.csv"

    domains_data = read_domains_from_csv(input_filename)

    if domains_data is not None:
        print(f"Всего записей в файле: {len(domains_data)}")

        timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        csv_filename = f"domains_parsed_{timestamp}.csv"
        excel_filename = f"domains_parsed_{timestamp}.xlsx"

        save_to_csv(domains_data, csv_filename)
        save_to_excel(domains_data, excel_filename)

        print("Обработка завершена.")
    else:
        print("Не удалось обработать данные.")
