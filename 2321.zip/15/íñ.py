import random
import csv
from faker import Faker
import ipaddress

fake = Faker()

def generate_ip():
    return str(ipaddress.IPv4Address(random.randint(1, 0xffffffff)))

def generate_port():
    return random.randint(1024, 65535)

def generate_domain():
    domain_name = fake.domain_name()
    ip = generate_ip()
    country = fake.country()
    port = generate_port()
    return (domain_name, ip, country, port)

def write_domains_to_file(filename='domains.csv', num=100000):
    with open(filename, mode='w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerow([
            'domain', 'ip', 'country', 'port',
            'owner_name', 'owner_email', 'registration_date', 'expiration_date'
        ])
        
        for _ in range(num):
            domain_data = generate_domain()
            owner_name = fake.name()
            owner_email = fake.email()
            registration_date = fake.date_this_decade(before_today=True, after_today=False)
            expiration_date = fake.date_between(start_date=registration_date, end_date='+3y')
            
            writer.writerow(domain_data + (owner_name, owner_email, registration_date, expiration_date))

def main():
    print("Starting data generation...")
    write_domains_to_file(num=100000)
    print("Data has been written to 'domains.csv'.")

if __name__ == '__main__':
    main()
