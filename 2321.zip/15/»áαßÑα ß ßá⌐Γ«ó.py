import requests
import pandas as pd
from datetime import datetime  
import csv
from bs4 import BeautifulSoup

def fetch_proxies_from_proxy_list():
    url = "https://www.proxy-list.download/api/v1/get?type=https"
    try:
        response = requests.get(url, headers={"User-Agent": "Mozilla/5.0"})
        response.raise_for_status()

        proxies = response.text.split('\r\n')
        proxy_list = []
        for proxy in proxies:
            if proxy:
                ip, port = proxy.split(":")
                proxy_list.append({"IP": ip, "Port": port, "Country": "Unknown"})

        return proxy_list
    except Exception as e:
        print(f"Ошибка при парсинге с proxy-list.download: {e}")
        return []

def fetch_proxies_from_freeproxylists():
    url = 'https://www.freeproxylists.net/'
    try:
        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'html.parser')

        proxies = []
        rows = soup.find_all('tr')
        for row in rows:
            cols = row.find_all('td')
            if len(cols) > 1:
                ip = cols[0].text.strip()
                port = cols[1].text.strip()
                proxies.append({"IP": ip, "Port": port, "Country": "Unknown"})
        
        return proxies
    except Exception as e:
        print(f"Ошибка при парсинге с freeproxylists.net: {e}")
        return []

def fetch_proxies_from_socks_proxy():
    url = 'https://www.socks-proxy.net/'
    try:
        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'html.parser')

        proxies = []
        for row in soup.find_all('tr'):
            cols = row.find_all('td')
            if len(cols) > 1:
                ip = cols[0].text.strip()
                port = cols[1].text.strip()
                proxies.append({"IP": ip, "Port": port, "Country": "Unknown"})

        return proxies
    except Exception as e:
        print(f"Ошибка при парсинге с socks-proxy.net: {e}")
        return []

def fetch_proxies_from_publicproxyservers():
    url = 'https://publicproxyservers.com/proxy/list/index.php'
    try:
        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'html.parser')

        proxies = []
        for row in soup.find_all('tr'):
            cols = row.find_all('td')
            if len(cols) > 1:
                ip = cols[0].text.strip()
                port = cols[1].text.strip()
                proxies.append({"IP": ip, "Port": port, "Country": "Unknown"})

        return proxies
    except Exception as e:
        print(f"Ошибка при парсинге с publicproxyservers.com: {e}")
        return []


def fetch_proxies_from_spys_one():
    url = "https://spys.one/en/free-proxy-list/"
    try:
        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'html.parser')

        proxies = []
        table = soup.find("table", {"class": "spy1xx"})
        if table:
            rows = table.find_all('tr')[1:]
            for row in rows:
                cols = row.find_all('td')
                if len(cols) > 1:
                    ip = cols[0].text.strip()
                    port = cols[1].text.strip()
                    proxies.append({"IP": ip, "Port": port, "Country": "Unknown"})
        return proxies
    except Exception as e:
        print(f"Ошибка при парсинге с spys.one: {e}")
        return []

def fetch_proxies_from_hidemy_name():
    url = "https://hidemy.name/en/proxy-list/"
    try:
        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'html.parser')

        proxies = []
        table = soup.find('table', {'class': 'table table-striped table-bordered'})
        if table:
            rows = table.find_all('tr')[1:]
            for row in rows:
                cols = row.find_all('td')
                if len(cols) > 1:
                    ip = cols[0].text.strip()
                    port = cols[1].text.strip()
                    proxies.append({"IP": ip, "Port": port, "Country": "Unknown"})
        return proxies
    except Exception as e:
        print(f"Ошибка при парсинге с hidemy.name: {e}")
        return []


def fetch_proxies_from_proxyscrape():
    url = "https://www.proxyscrape.com/free-proxy-list"
    try:
        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'html.parser')

        proxies = []
        table = soup.find('table', {'class': 'table table-striped'})
        if table:
            rows = table.find_all('tr')[1:]
            for row in rows:
                cols = row.find_all('td')
                if len(cols) > 1:
                    ip = cols[0].text.strip()
                    port = cols[1].text.strip()
                    proxies.append({"IP": ip, "Port": port, "Country": "Unknown"})
        return proxies
    except Exception as e:
        print(f"Ошибка при парсинге с proxyscrape.com: {e}")
        return []

def fetch_all_proxies():
    proxies = []
    
    proxies += fetch_proxies_from_proxy_list()
    proxies += fetch_proxies_from_freeproxylists()
    proxies += fetch_proxies_from_socks_proxy()
    proxies += fetch_proxies_from_publicproxyservers()
    proxies += fetch_proxies_from_spys_one()
    proxies += fetch_proxies_from_hidemy_name()
    proxies += fetch_proxies_from_proxyscrape()

    return proxies

def save_to_csv(proxies, filename):
    try:
        with open(filename, mode="w", newline="", encoding="utf-8") as file:
            writer = csv.DictWriter(file, fieldnames=["IP", "Port", "Country"])
            writer.writeheader()
            writer.writerows(proxies)
        print(f"Данные сохранены в файл: {filename}")
    except Exception as e:
        print(f"Ошибка при сохранении файла: {e}")

def save_to_excel(proxies, filename):
    try:
        df = pd.DataFrame(proxies)  
        df.to_excel(filename, index=False) 
        print(f"Данные сохранены в Excel файл: {filename}")
    except Exception as e:
        print(f"Ошибка при сохранении в Excel: {e}")

if __name__ == "__main__":
    print("Парсим список прокси...")
    proxies = fetch_all_proxies()

    if proxies:
        print(f"Найдено {len(proxies)} прокси.")
        for proxy in proxies[:10000]:  
            print(proxy)

        timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")  
        csv_filename = f"proxies_{timestamp}.csv"  
        excel_filename = f"proxies_{timestamp}.xlsx" 

        save_to_csv(proxies, csv_filename)
        save_to_excel(proxies, excel_filename)

    else:
        print("Не удалось найти прокси.")
